package com.biz.memo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.biz.memo.mapper.MemberDao;
import com.biz.memo.model.MemberVO;

@Service
public class MemberService {

	@Autowired
	MemberDao mdao;
	
	public List<MemberVO> findByUserid(MemberVO membervo) {
		
		return mdao.findByUserid(membervo);
	}
	
	public int insert(MemberVO membervo) {
		
		return mdao.insert(membervo);
	}
}
