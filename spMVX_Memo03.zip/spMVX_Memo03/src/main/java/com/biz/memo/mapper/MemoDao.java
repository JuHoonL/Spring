package com.biz.memo.mapper;

public interface MemoDao {
	
	public void selectAll();
	public void findById();
	public void insert();
	public void update();
	public void delete();
}
